const express =require('express');
var path = require('path');
const port = 8080;
const app = express();
const res =require('http');
var mysql =require('mysql');
const fileupload =require('express-fileupload');
const { name } = require('ejs');
var uploadPath;
var file;
var result;
var dirname;
var files;
var test;
var i;
var fs =require('fs');
const filetype =require('file-type')
const ejsLint = require('ejs-lint');
var result3;
var pdf;
var png;
var audio;
var user;
var passwordHash = require('password-hash');
var md5= require('md5');
var sess;
var result1;
const session = require('express-session');



 app.use(session({
     secret: 'ssshhhhh',
     resave: true,
     saveUninitialized: true

}));



const directory = path.join(__dirname,'public')
app.use('/public',express.static(directory));


app.set('views','./views');
app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.urlencoded({
  extended: true
}));




var connexion;
var select;
//connexion sql//
app.get('/fichier',function(req,res){
   
     connexion = mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'',
        database:'nodejs',
    });
   
    connexion.connect(function(err){
        if(err) throw err;
        //console.log("connected");
        select ="SELECT nomFichier,typeFichier FROM fichierNodeJS";
        connexion.query(select,function(err,result,fields){
            if (err) throw err;
            for(i = 0; i < result.length;i++){
                 result1 =result[i].nomFichier;
                 
            }
           
                sess =req.session;
                res.render('pages/fichier',{dirname:dirname,test:test,result1:result,sess:sess});
                sess =req.session;
                
            })
    });
    var selectCateg="SELECT categorienodejs.libelle ,fichiernodejs.typeFichier FROM fichiernodejs JOIN categorienodejs on fichiernodejs.idFichier=categorienodejs.IdCateg";
    
      connexion.query(selectCateg,function(req,res){
            console.log(res);
        })

    
})

    
var other;
var categ;
var images;    
app.get('/categorie1',function(req,res){
    var connexion = mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'',
        database:'nodejs',
    });
    connexion.connect(function(err){
        if (err) throw err;
        var select2 ="SELECT nomFichier,typeFichier FROM fichierNodeJS WHERE typeFichier='image/jpeg'";
        connexion.query(select2,function(err,result){
            if (err) throw err;
           result3 =result
            
        })
        var select3 ="SELECT nomFichier,typeFichier FROM fichierNodeJS WHERE typeFichier='application/pdf'";
        connexion.query(select3,function(err,result2){
            if(err) throw err;
            pdf =result2;
            
        })
        var select4 ="SELECT nomFichier,typeFichier FROM fichierNodeJS WHERE typeFichier='image/png'OR typeFichier ='image/jpeg'";
        connexion.query(select4,function(err,result5){
            if(err) throw err;
             images =result5;
        })
        var divers ="SELECT nomFichier,typeFichier FROM fichierNodeJS WHERE typeFichier='audio/mpeg' OR typeFichier='video/mp4'";
        connexion.query(divers,function(err,result6){
            if(err) throw err;
            console.log(result6);
            audio = result6;
        })
        var autres ="SELECT nomFichier,typeFichier FROM fichierNodeJS WHERE typeFichier='application/octet-stream'";
        connexion.query(autres,function(err,result7){
            if(err) throw err;
            console.log(result7);
            other=result7;
            
        })
        var selectCateg ='SELECT * from categorienodejs';
        connexion.query(selectCateg,function(req,res){
            console.log(res);
            categ =res;
        })
        res.render('pages/categorie',{categ:categ,image:result3,pdf:pdf,images:images,audio:audio,other:other});
    })
   
})

 app.get('/inscription',function(req,res){
     res.render('pages/inscription');
 })
 //validation des données et insertions//
 app.post('/inscription',function(req,res){
    var connexion = mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'',
        database:'nodejs',
        
        
       
        
       
    });
    var user= "INSERT INTO UserNodeJs(Id,pseudo,nom,prenom,mot_de_passe,mail) VALUES ?";
    var prenom =req.body.prenom;
    var pseudo = req.body.pseudo;
    var mail =req.body.email;
    var nom =req.body.nom;
    var mdp =req.body.password;
    var hash =md5(mdp);
    console.log(hash);
    var value =[
        ['',pseudo,nom,prenom,hash,mail]
    ];
    connexion.query(user,[value],function(err,resultUser){
        if(err)throw err;
        console.log('connected')
        console.log(resultUser);
    })
    res.send('utilisateur inseré');
    
 })
 app.get('/connexion',function(req,res){
   res.render('pages/connexion')
 })
 var resultData1;
 
 
 app.post('/connect',function(req,res){
    //selectionné les données utilisateurs pour les comparé//
    var connexion = mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'',
        database:'nodejs',
    });
    
    var selectData ="SELECT pseudo,mot_de_passe FROM usernodejs";
    connexion.query(selectData,function(err,resultData){
        if(err) throw err;
        resultData1=resultData
        console.log(resultData1.length)
        //selectionné toutes les données en bdd dans une boucle//
        for(var x =0;x<resultData1.length;x++){
            console.log(resultData1[x].pseudo);
            console.log(resultData1[x].mot_de_passe);
            console.log(md5(req.body.password1));
            //si le pseudonyme entré en champ utilisateur est bon,on rentre dans la boucle//
            if(req.body.pseudonyme==resultData1[x].pseudo){
                console.log('bon pseudo');
                //si le mot de passe entré par l'utilisateur est bon,on connecte l'utilisateur a une session//
                if(md5(req.body.password1)==resultData1[x].mot_de_passe){
                    console.log('bon mot de passe');
                    sess =req.session;
                    sess.pseudo =req.body.pseudonyme;
                    req.session.save();
                    //on redirige une fois connecté a la page d'accueil une fois connecté//
                    res.render('index',{ title: user,sess:sess});
                }
                res.end();
                
            }
        }
        
    })
    
})
app.get('/session',function(req,res){
    //affichage de la session sur la page d'accueil//
    console.log(sess.pseudo)
    res.render('pages/session');
})
app.get('/deconnexion',function(req,res){
    // destruction de la session//
    req.session.destroy(function(err){
        if(err) throw err;
        res.redirect('/')
    })
})

app.get('/',function(req,res){
    user ="forum";
    sess =req.session;
    res.render('index', { title: user,sess:sess});
});


//upload files//
const fileUpload = require('express-fileupload');
const { throws } = require('assert');
app.use(fileUpload({
    uploadTimeout:60000
}));

console.log(__dirname)
var sql;

app.post('/upload',function(req,res){
    
    var name =req.files.upload.name;
   var size = req.files.upload.size;
    type =req.files.upload.mimetype
    var images= [name,size]
    //res.send(images);
    sess =req.session;
    console.log(sess.pseudo);
    connexion = mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'',
        database:'nodejs',
    });
    connexion.connect(function(err){
        if(err) throw err;
        console.log("connected");
        
                var insert = "INSERT INTO fichiernodejs(idFichier,nomFichier,taille,typeFichier) VALUES ?";
                var values =[
                        ["",name,size,type]
                ];
       sql = "SELECT usernodejs.id,nomFichier from usernodejs LEFT JOIN fichiernodejs ON usernodejs.id = fichiernodejs.id";
        
       connexion.query(sql,function(err,result){
            console.log(result);
        })
            connexion.query(insert,[values],function(err,result){
                if(err) throw err;
                console.log(result);
               
             })
             
       
             
            
         
        });
        console.log(req.body.categorie);
    
    file = req.files.upload;
    nameFile =file.name;
    dirname =__dirname;
    uploadPath =__dirname + '/public/upload/upload'+ file.name;
    file.mv(uploadPath,function(err){
        if(err){
            return res.status(500).send(err)
        }
       
        
    });
    res.end();
  
    
})

app.post('/suppression',function(req,res){
    
    var select;
    var result1;
    sess =req.session;
    connexion = mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'',
        database:'nodejs',
    });
    select ="SELECT idFichier, nomFichier FROM fichiernodejs";
    var idFichier;
    connexion.query(select,function(err,result){
        if (err) throw err;
        for(var i =0; i < result.length;i++){
            
             result1 =result[i].nomFichier;
             idFichier= result[i].idFichier;
            console.log(result1);
         }
         
         var supprimer ="DELETE FROM fichiernodejs WHERE idFichier =?";
        var idRec =[
            [idFichier]
        ];
        connexion.query(supprimer,[idRec],function(req,resultats){
            console.log(resultats.affectedRows);
        })
    })
    
})
const { body, validationResult } = require('express-validator');

app.post('/categorie',function(req,res){
   
          var categorie =req.body.categorie;
          console.log(categorie);
          connexion = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'',
            database:'nodejs',
        });
          
              var ajoutCateg ="INSERT INTO categorienodejs(idCateg,libelle) VALUES ?";
              var valeurs=[
                  ["",categorie]
              ];
              connexion.query(ajoutCateg,[valeurs],function(req,resCategorie){
                  console.log(resCategorie)
              })
              
              
        
         
    }) 
    var users;
    var select;
    var idUser;
    app.get('/messages',function(req,res){
        connexion = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'',
            database:'nodejs',
        });
        sess =req.session;
        
        connexion.connect(function(err){
             select ="SELECT id,pseudo FROM usernodejs WHERE id NOT IN(11)"
             var testid;
            connexion.query(select,function(err,resultats){
                if(err) throw err;
                for(i =0; i < resultats.length;i++){
                    users =resultats[i].pseudo;
                    idUser= resultats[i].id;
                  
                   
                }
                
               
                sess =req.session;
                
                //consultation des messages//
                var messages = "select * from usernodejs,messagesnodejs WHERE usernodejs.id=messagesnodejs.idUser ";
                
                var message1;
                connexion.query(messages,function(err,messages){
                    if(err)throw err;
                   
                    for(i=0;i<messages.length;i++){
                        message1 = messages[i];
                        console.log(messages);
                    }
                    
                    res.render('pages/messages',{users:resultats,message1:messages,test:test,sess:sess})
                })
                
               
                
            })
            
        })
       
            
      
        
    })
    var message;
    app.post('/msg',function(req,res){
        connexion = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'',
            database:'nodejs',
        });

       
        
        sess =req.session;
        message=req.body.msg;
        
        var join = "select usernodejs.pseudo,messagenodejs.contenu from usernodejs,messagesnodejs WHERE usernodejs.id=messagesnodejs.idUser ";
       
        var insertMsg ="INSERT INTO messagesnodejs(idMessages,contenu,IdUser)VALUES ?";
        var val =[
            ['',message,idUser]
        ]
        
        connexion.query(insertMsg,[val],function(err,envoie){
            if(err)throw err;
            console.log(envoie.affectedRows);
        })
       
      
        
    })
 
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})
